# Configuration for
# iCalTV by Henrik Nyh <http://henrik.nyh.se> 2006-09-02

SCRIPT_DIR = File.dirname(File.expand_path($0)).to_s unless defined?(SCRIPT_DIR)
require "#{SCRIPT_DIR}/lexml.rb"


class String
	def qualify_home_dir!
		replace(self.sub("~", "/Users/#{ENV['USER']}"))
	end
end

# The number of days to retrieve schedules for every time the grabber is run.
# 0 = none, 1 = yesterday and today, 2 = yesterday, today and tomorrow, ...
# The odd numbering is due to the fact that you need yesterday's data for early morning programmes.

FETCH_DAYS = 7

DATA_DIR           = "~/Library/Xmltv".qualify_home_dir!
SERVER_DIR         = "#{DATA_DIR}/server"
SCHEDULE_DIR       = "#{DATA_DIR}/schedules"
LOGO_DIR           = "#{DATA_DIR}/logos"
FAVORITE_DIR       = "#{DATA_DIR}/favorites"
ICAL_DIR           = "#{DATA_DIR}/ical"
ICAL_UPDATED_FILE  = "#{ICAL_DIR}/updated.at"
SOUND_DIR          = "#{ICAL_DIR}/sounds"
ALERT_FILE         = "#{SOUND_DIR}/alarm.wav"
ICAL_TEMPLATE_DIR = "#{ICAL_DIR}/scripts_templates"
ICAL_SCRIPT_DIR   = "#{ICAL_DIR}/scripts_rendered"
ROOT_FILE          = "#{SERVER_DIR}/channels.xml"
CHANNELS_FILE      = "#{FAVORITE_DIR}/channels.xml"
FAVORITES_FILE     = "#{FAVORITE_DIR}/rulesets.xml"

SCRIPT_TEMPLATE_DIR = "#{SCRIPT_DIR}/templates"
SCRIPT_SCRIPT_DIR = "#{SCRIPT_TEMPLATE_DIR}/alertscripts"

ROOT_URL       = "http://xmltv.tvsajten.com/xmltv/channels.xml.gz"

SCHEDULE_REGEXP = /(.+)_(\d{4}-\d{2}-\d{2})\.xml$/

USER_AGENT     = "iCalTVGrabber/0.7"