#! /usr/bin/env ruby

# iCalTV Engine by Henrik Nyh <http://henrik.nyh.se> 2006-09-02
# Free to modify and redistribute non-commercially with due credit.

# Compares XMLTV schedules to rulesets and exports the intersection to iCal.

SCRIPT_DIR = File.dirname(File.expand_path($0)).to_s unless defined?(SCRIPT_DIR)
require "#{SCRIPT_DIR}/configuration.rb"


# Retrieve new schedules (if necessary)

catch :wont_grab do
	require "#{SCRIPT_DIR}/grabber.rb"
end


# Only proceed if necessary, e.g. if there is data newer than the last export
if (File.exist?(ICAL_UPDATED_FILE))
	calendar_mod = File.mtime(ICAL_UPDATED_FILE)
	file_mods = [File.mtime(FAVORITES_FILE)]
	Dir.foreach(SCHEDULE_DIR) do |filename|
		next unless filename =~ SCHEDULE_REGEXP  # Only properly named XML files
		filepath = "#{SCHEDULE_DIR}/#{filename}"
		file_mods << File.mtime(filepath)
	end
	Dir.foreach(ICAL_TEMPLATE_DIR) do |filename|
		next unless filename =~ /\.scpt$/
		filepath = "#{ICAL_TEMPLATE_DIR}/#{filename}"
		file_mods << File.mtime(filepath)
	end
	if file_mods.all? {|file_mod| file_mod < calendar_mod}
		exit if $cron  # Exit entirely if croned
		throw :wont_ical  # Only break out to install.rb, if required by it
	end
end


# If we didn't bail, go on and set iCal from favorites

require "date"
require "time"
require "iconv"

class String
	def escape
		self.gsub('"', '\"')
	end
	ELLIPSE_LIMIT = 43
	def elliptic
		(size > ELLIPSE_LIMIT) ? slice(0, ELLIPSE_LIMIT-3) + "…".macRoman : self
	end
	def macRoman
		begin
			return Iconv.new('MacRoman', 'UTF8').iconv(self)
		rescue
			return self
		end
	end
end

class Ruleset < Array
	DEFAULT_MATCH = :all
	attr_reader :alerts
	def initialize(xml_ruleset)
		@alerts = Alert.collect(xml_ruleset)
		@setname, @setmatch = xml_ruleset[:name, :match]
		add(xml_ruleset.children(:rule).map { |xml_rule| Rule.from_xml(xml_rule) })
	end
	def add(array)
		insert(0, *array)
	end
	def all_match?(programme)
		all? { |rule| programme.fulfills? rule }
	end
	def any_match?(programme)
		any? { |rule| programme.fulfills? rule }
	end
	def contain_name_rule?
		any? {|rule| rule.attribute == :name}
	end
	def name
		@setname || first.value
	end
	def match
		@setmatch ? @setmatch.to_sym : DEFAULT_MATCH
	end
end

class Rule
	attr_reader :attribute, :condition, :value
	def initialize(attribute, condition, value)
		@attribute, @condition, @value = attribute, condition, value
	end
	def self.from_xml(rule)
		self.new(rule[:attribute].to_sym, rule[:condition].to_sym, rule.to_s)
	end
end

class Programme
	attr_reader :name, :channel_id, :categories, :desc, :actors, :starts, :stops, :rule_summary
	attr_accessor :actor, :category, :ruleset
	TEXT_ATTRIBUTES = [:name, :channel, :channel_id, :desc]
	TIME_ATTRIBUTES = [:starts, :stops, :plays]
	LIST_ATTRIBUTES = {:actor => :actors, :category => :categories}

	def initialize(xml_programme)
		@name = xml_programme.child("title")
		@desc = xml_programme.child("desc") || ""
		@channel_id, @starts, @stops = xml_programme[:channel, :start, :stop]
		@starts, @stops = Time.parse(@starts), Time.parse(@stops)
		@actors = xml_programme.children("credits/actor")
 		@categories = xml_programme.children("category").map { |xml_category| xml_category.downcase }
	end

	def channel
		ID_TO_CHANNEL[@channel_id] || @channel_id
	end

	def summary
		"#{channel}: #{@name} #{rule_summary}\\n".macRoman + desc.macRoman.elliptic
	end
	
	def rule_summary
		ruleset.contain_name_rule? ? "" : "[#{ruleset.name}] "
	end
	
	def expired?
		Time.now > @stops
	end
	
	def applescript
		alerts = @ruleset.alerts || DEFAULT_ALERTS || []
		alarms = alerts.select {|alert| alert.alarm?}
		scripts = alerts.select {|alert| alert.script?}
		
		event = []

		event << %{set startDate to date "#{starts.strftime('%H:%M')}"}
		event << "set year of startDate to #{starts.year}"
		event << "set day of startDate to #{starts.day}"
		event << "set month of startDate to #{starts.month}"

		event << %{set endDate to date "#{stops.strftime('%H:%M')}"}
		event << "set year of endDate to #{stops.year}"
		event << "set day of endDate to #{stops.day}"
		event << "set month of endDate to #{stops.month}"
		
		event << %{set this_event to make new event at end of events with properties {start date:startDate, end date:endDate, summary:"#{summary.escape}", description:"#{desc.macRoman.escape}"}}
		event << "tell this_event"
		event << "	delete every sound alarm -- get rid of any default alarm"
		
		# TODO: Document this. foo.wav = Xmltv/ical/sounds/foo.wav; foo = systemljud; x/y/foo.wav = sökväg
		alarms.each do |alarm|
			file = alarm.sound
			file = "#{SOUND_DIR}/#{file}" if file.include?(".") and file.index(%r{[/~]}) != 0  # In default dir
			file.qualify_home_dir!
			sound_property = file.include?(".") ? "file" : "name"
			sound_property = %{sound #{sound_property}:"#{file}"}
			event << "	make new sound alarm at end of sound alarms with properties {trigger interval:-#{alarm.before}, #{sound_property}}"
		end

		scripts.each do |script|
			rendered_script = "#{ICAL_SCRIPT_DIR}/#{script.template}-#{@channel_id}_#{starts.strftime('%Y-%m-%d_%H-%M')}_#{script.before}.scpt"
			
			# Create script file			
			script_template = File.new("#{ICAL_TEMPLATE_DIR}/#{script.template}.scpt").read

			replacements = [
				[:before, script.before],
				[:start_time, starts.strftime('%H:%M')],
				[:end_time, stops.strftime('%H:%M')],
				[:end_timestamp, stops.to_i],
				[:channel_logo, "#{LOGO_DIR}/#{channel_id}.png"]
			] +
			[:name, :channel, :desc, :rule_summary].map do |attribute|
				[attribute, send(attribute).macRoman.escape]
			end
			
			replacements.each do |replacement|  # Replace placeholders
				script_template.gsub!("(*#{replacement.first.to_s.upcase}*)", replacement.last.to_s)
			end
			
			File.open(rendered_script, "w") do |file|
				file.puts script_template
			end
			
			# Call it
			event << %{	make new open file alarm at end of open file alarms with properties {trigger interval:-#{script.before}, filepath:"#{rendered_script}"}}
	end

		event << "end tell"

		event.join("\n")
	end

	def favorite?
		FAVORITE_RULESETS.any? do |ruleset|
			case ruleset.match
			when :all
				success = ruleset.all_match? self
			when :any
				success = ruleset.any_match? self
			end
			self.ruleset = ruleset if success  # Make programme aware of the lucky ruleset
			success
		end
	end

	def fulfills?(rule)
		attribute, condition, value = rule.attribute, rule.condition, rule.value
    
		if (condition.to_s.index("not-") == 0)
			# Condition begins with "not-"
			reverse_condition = condition.to_s[4..-1].to_sym
			return !fulfills?(Rule.new(attribute, reverse_condition, value))

		elsif (Programme::TEXT_ATTRIBUTES.include?(attribute) ||
		      (Programme::LIST_ATTRIBUTES.include?(attribute) && send(attribute)))
			# Text attribute, directly or indirectly (by way of list attribute)
			attribute = send(attribute)
			case condition
			when :is
				return attribute == value
			when :contains
				return attribute.include?(value)
			when :"begins-with"
				return attribute.index(value) == 0
			when :"ends-with"
				return attribute.rindex(value) == (attribute.size - value.size)
			end  # case

		elsif (Programme::LIST_ATTRIBUTES.include?(attribute) && !send(attribute))
			# List attribute
			plural = LIST_ATTRIBUTES[attribute]
			return send(plural).any? do |entry|
				send("#{attribute.to_s}=", entry)  # e.g. @actor = "Foo Bar"
				fulfills?(Rule.new(attribute, condition, value))
			end
			send("#{attribute.to_s}=", nil)			

		elsif (Programme::TIME_ATTRIBUTES.include?(attribute))
			# Time attribute	
			if attribute == :plays  # :plays
				if value.include?("-")
					fulfills?(Rule.new(:starts, :within, value)) &&
					fulfills?(Rule.new(:stops, :within, value))
				end
			else  # :starts or :stops
				attribute = send(attribute).strftime("%H%M%S").to_i			
				if value.include? "-"  # assume condition is :within
					value =~ /(\d+):(\d+)-(\d+):(\d+)/
					start_value, end_value = "#{$1}#{$2}00".to_i, "#{$3}#{$4}00".to_i
					if end_value < start_value
						return Range.new(start_value,240000).include?(attribute) || Range.new(0, end_value).include?(attribute)
					elsif start_value < end_value
						return Range.new(start_value, end_value).include?(attribute)
					else
						return attribute == start_value
					end
				else  # just assume condition is :at
					value = value.sub(/:(\d+)/, "\\100").to_i
					return attribute == value
				end
			end
		end
    
	end  # method fulfills?

end  # class Programme

class Alert
	attr_accessor :before
	def initialize(before, source, type)
		@before = before
		@source = source
		@type = type
	end
	def self.collect(xml_node)
		collection = []
		return nil unless (xml_node and xml_node.child(:alerts))
		xml_node.child(:alerts).children.each do |alert|
			alert[:before].split(/\s*,\s*/).each do |before|
				alert.split(/\s*,\s*/).each do |source|
					collection << Alert.new(before, source, alert.name)
				end
			end
		end
		collection
	end
	def alarm?
		@type=="alarm"
	end
	def script?
		@type=="script"
	end
	def template
		@source if script?
	end
	def sound
		@source if alarm?
	end
end


# Retrieve defaults and rulesets

xml = LEXML.new(FAVORITES_FILE)

DEFAULT_ALERTS = Alert.collect(xml.root)
FAVORITE_RULESETS = xml.root.children(:ruleset).map do |xml_ruleset|
	ruleset = Ruleset.new(xml_ruleset)
end


# Map channel IDs to channel names

ID_TO_CHANNEL = {}
begin  # File broken or missing?
	xml = LEXML.new(CHANNELS_FILE)
	xml.root.children("channel").each do |xml_channel|
		ID_TO_CHANNEL[xml_channel[:id]] = xml_channel.to_s
	end
rescue
end


# Clear old temporary reminder scripts

`rm -f #{ICAL_SCRIPT_DIR}/*.scpt`

# Generate events

events = []

Dir.foreach(SCHEDULE_DIR) do |schedule_filename|	
	next unless schedule_filename =~ SCHEDULE_REGEXP  # Only XML files

	filepath = "#{SCHEDULE_DIR}/#{schedule_filename}"
	if Date.parse($2) < Date.today-1  # Expired schedules
		File.delete(filepath)
		next
	end
  
	begin  # catch XML initiation errors, typically incomplete file
		xml = LEXML.new(filepath)
	rescue
		next
	end
    
	xml.root.children("programme").each do |xml_programme|
    
		programme = Programme.new(xml_programme)
		next if programme.expired?
    	events << programme.applescript if programme.favorite?

	end
end unless FAVORITE_RULESETS.empty?  # don't bother if there are no favorites


# Create the updater AppleScript

UPDATER_SCRIPT = "#{ICAL_SCRIPT_DIR}/icaltv.scpt"
updater = File.new("#{SCRIPT_DIR}/templates/ical.scpt").read
updater.sub!("(*EVENTS*)", events.join("\n"))

File.open(UPDATER_SCRIPT, "w") {|script| script.puts updater}

# Run the updater AppleScript, passing in the location of updated.at

`osascript #{UPDATER_SCRIPT} "#{ICAL_UPDATED_FILE}"`