#! /usr/bin/env ruby

# iCalTV Grabber by Henrik Nyh <http://henrik.nyh.se> 2006-09-02
# Free to modify and redistribute non-commercially with due credit.

# Retrieves XMLTV schedules and icons according to configuration.rb.
# Calls the cleaner to remove expired data.

SCRIPT_DIR = File.dirname(File.expand_path($0)).to_s unless defined? SCRIPT_DIR
require "#{SCRIPT_DIR}/configuration.rb"
require "date"


throw :wont_grab if FETCH_DAYS.zero?  # Bail immediately if not instructed to retrieve at all


xml = LEXML.new(CHANNELS_FILE)
userchannels = xml.root.children(:channel).map { |channel| channel[:id] }

throw :wont_grab if userchannels.all? do |channel|
	File.exist?("#{SCHEDULE_DIR}/#{channel}_#{Date.today-1+FETCH_DAYS}.xml")
end

# If all schedules are current, we threw. The iCalTV engine will catch this.
# If we didn't throw, not all schedules are current!


# Remove expired data

require "#{SCRIPT_DIR}/cleaner.rb"


# Set us up the bomb

def conditionally_get(url, file, ignore_date = false)
	return 304 if (ignore_date && File.exist?(file))
	status_code = `curl -R --user-agent #{USER_AGENT} --compressed #{url} -o #{file} -z #{file} --write-out "%{http_code}" 2> /dev/null`.to_i
	raise "Unexpected status code #{status_code} for #{url}!" unless [200, 304].include?(status_code)
	status_code
end


# Get root file

conditionally_get(ROOT_URL, ROOT_FILE)


# Store base-url and icon from it

ROOT_DATA = {}
xml = LEXML.new(ROOT_FILE)

## userchannels?

xml.root.children(:channel).each do |channel|
	ROOT_DATA[channel[:id]] = {
		:base_url => channel.child("base-url"),
		:icon => channel.child(:icon) ? channel.child(:icon)[:src] : nil
	}
end

# For each user channel, retrieve schedules and icons if changed

status_codes = []

xml = LEXML.new(CHANNELS_FILE)
xml.root.children(:channel).each do |channel|
	channel = channel[:id]
	base_url = ROOT_DATA[channel][:base_url]
	icon = ROOT_DATA[channel][:icon]

	# Get schedules
	(Date.today-1).upto(Date.today-1+FETCH_DAYS) do |day|
		filename = "#{channel}_#{day}.xml"
		status_codes << conditionally_get("#{base_url}#{filename}.gz", "#{SCHEDULE_DIR}/#{filename}")
	end
	# Get logo
	next unless icon
	url = icon
	filename = File.basename(url)
	conditionally_get(url, "#{LOGO_DIR}/#{filename}", true)
end