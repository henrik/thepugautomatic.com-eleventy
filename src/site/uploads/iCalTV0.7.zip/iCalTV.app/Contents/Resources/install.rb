# iCalTV installation by Henrik Nyh <http://henrik.nyh.se> 2006-09-02
#
# Sets you up the bomb.

require "ftools"

class AppleScript
	def initialize(*args)
		@args = args
	end
	def self.timeless(*args)  # TODO: Otestad
		args = ['with timeout of 9999 seconds'] + args + ["end timeout"]
		self.new(*args)
	end
	def self.info(text)
		'display dialog "'+text.to_s+'" with icon note buttons {"OK"}'
	end
	def run
		a = @args.map {|arg| "-e '#{arg}'" }.join(' ')
		`osascript #{a}`
	end
end


# libxml?

begin
	require "rubygems"
	require "xml/libxml"
rescue LoadError => foo  # No libxml
	AppleScript.new(
	'with timeout of 9999 seconds',
		'tell app "iCalTV"',
			'activate',
			'set chosenButton to display dialog "Du verkar inte ha Ruby-biblioteket libxml installerat. Om du installerar det (n�got tekniskt) kommer iCalTV g� betydligt snabbare." with icon note buttons {"Visa instruktioner", "Installera ej"} default button "Visa instruktioner"',
			'set choice to button returned of chosenButton',
			'if choice = "Visa instruktioner"',
				'do shell script "open \\"http://docs.rubygems.org/read/chapter/3#page13\\"; open \\"http://libxml.rubyforge.org/install.html\\""',
				'activate',
				AppleScript::info("Enklaste installationsf�rfarandet �r att installera RubyGems, och sedan libxml genom RubyGems. Instruktioner f�r respektive installation har �ppnats i din webbl�sare.\n\nTryck OK n�r du installerat libxml eller om du vill forts�tta �nd�."),
			'end if',
		'end tell',
	'end timeout'
	).run
end


SCRIPT_DIR = File.dirname(File.expand_path($0)) unless defined? SCRIPT_DIR
require "#{SCRIPT_DIR}/configuration.rb"


# Create files and directories if necessary

File.makedirs(SERVER_DIR, SCHEDULE_DIR, LOGO_DIR, FAVORITE_DIR, SOUND_DIR, ICAL_TEMPLATE_DIR, ICAL_SCRIPT_DIR)

[CHANNELS_FILE, FAVORITES_FILE, ALERT_FILE].each do |file|
	next if File.exist? file
	File.copy("#{SCRIPT_TEMPLATE_DIR}/#{File.basename(file)}", file)
end

# Copy script templates

Dir.foreach(SCRIPT_SCRIPT_DIR) do |filename|
	startpath = "#{SCRIPT_SCRIPT_DIR}/#{filename}"
	endpath = "#{ICAL_TEMPLATE_DIR}/#{filename}"
	next if filename[0,1] == "." or File.exist?(endpath)
	File.copy(startpath, endpath)
end


# Prompt user to edit files

AppleScript.new(
	'with timeout of 9999 seconds',
		'tell app "Finder"',
			"reveal POSIX file \"#{CHANNELS_FILE}\"",
			'activate',
		'end tell',
		'tell app "iCalTV"',
			'activate',
			AppleScript::info("Innan konfigurationen forts�tter b�r du redigera #{CHANNELS_FILE} och #{FAVORITES_FILE} enligt medf�ljande README-fil.\n\nEtt Finder-f�nster med filerna har �ppnats i bakgrunden.\n\nTryck OK n�r detta �r gjort, f�r att forts�tta."),
			AppleScript::info("Tabl�er kommer laddas ner och h�ndelser skrivas till iCal. Detta kan ta ett tiotal sekunder.\n\nTryck OK f�r att b�rja."),
		'end tell',
	'end timeout'
).run

# Run script

catch :wont_ical do
	require "#{SCRIPT_DIR}/icaltv.rb"
end


# Modify the crontab

crontab = `crontab -l 2>/dev/null`.split("\n")
crontab.reject! {|job| job.include? "iCalTV"}  # remove old iCalTV tasks
ruby = `test -e /usr/local/bin/ruby && echo -n /usr/local/bin/ruby || echo -n ruby`  # fake PATH
crontab << "*/15 * * * * #{ruby} -s #{SCRIPT_DIR}/icaltv.rb -cron"
IO.popen("crontab -", "w") { |out| out.puts crontab.join("\n") }  # write


# iCal info

AppleScript.new(
	'with timeout of 9999 seconds',
		'tell app "iCalTV"',
			'activate',
			AppleScript::info("Nu �r allt klart. N�r du trycker OK kommer installationsprocessen avslutas.\n\nProgrammet kommer sk�ta sina uppgifter automatiskt. Om du tar bort eller flyttar programmet slutar iCalTV funka - l�s mer i README-filen. Kalendern iCalTV b�r inte redigeras manuellt."),
		'end tell',
	'end timeout'
).run