#! /usr/bin/env ruby

# iCalTV Cleaner by Henrik Nyh <http://henrik.nyh.se> 2006-09-10
# Free to modify and redistribute non-commercially with due credit.

# Deletes any expired (from before yesterday) schedules, as well as
# schedules and logos for channels that you no longer want.

SCRIPT_DIR = File.dirname(File.expand_path($0)).to_s unless defined?(SCRIPT_DIR)
require "#{SCRIPT_DIR}/configuration.rb"
require "date"


unless defined?(userchannels)  # grabber.rb should have set these already
	xml = LEXML.new(CHANNELS_FILE)
	userchannels = xml.root.children(:channel).map { |channel| channel[:id] }
end

Dir.foreach(SCHEDULE_DIR) do |filename|
	next unless filename =~ SCHEDULE_REGEXP  # Only properly named XML files
	filepath = "#{SCHEDULE_DIR}/#{filename}"
	File.delete(filepath) if (Date.parse($2) < Date.today - 1)  # Schedules older than yesterday are expired
	unless userchannels.include?($1)  # No longer a favorite channel
		File.delete(filepath)  # Remove schedule
		begin
			File.delete("#{LOGO_DIR}/#{$1}.png")  # Remove logo (making the assumption it is a PNG)
		rescue Errno::ENOENT
			# If logo does not exist, fail silently
		end
	end
end