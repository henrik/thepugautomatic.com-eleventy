/*
author>
            Matthias Hader (R/GA)
            Nick Coronges (R/GA)
            Jeff Baxter (R/GA) - Design
</author>
<company>NIKE</company>
<copyright>(c)2006 NIKE ALL RIGHTS RESERVED</copyright>
 */
var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0,firstElement:null, timer:null};

function enterFrame() {
	if (!flipShown) {
		if (animation.timer != null) {
			clearInterval (animation.timer);
			animation.timer = null;
		}

		var starttime = (new Date).getTime() - 13;
		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ('flip');
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = .75;
		animate();
		flipShown = true;
	}
}

function exitFrame(event){
	if (flipShown) {
		// fade in the info button
		if (animation.timer != null) {
			clearInterval (animation.timer);
			animation.timer = null;
		}

		var starttime = (new Date).getTime() - 13;
		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ('flip');
		animation.timer = setInterval ("animate();", 13);
		animation.from = animation.now;
		animation.to = 0.0;
		animate();
		flipShown = false;
	}
}

function animate() {
	var T;
	var ease;
	var time = (new Date).getTime();
	T = limit_3(time-animation.starttime, 0, animation.duration);
	if (T >= animation.duration) {
		clearInterval (animation.timer);
		animation.timer = null;
		animation.now = animation.to;
	} else {
		ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
		animation.now = computeNextFloat (animation.from, animation.to, ease);
	}
	animation.firstElement.style.opacity = animation.now;
}

function limit_3 (a, b, c) {
	return a < b ? b : (a > c ? c : a);
}

function computeNextFloat (from, to, ease) {
	return from + (to - from) * ease;
}

function doneButtonClicked(elementID){
	var doneButton = document.getElementById(elementID);
	doneButton.style.background = "url(Done_black.png) no-repeat top left";
}

function doneButtonReleased(elementID){
	var doneButton = document.getElementById(elementID);
	flipSide('back','front','ToFront');
}

function hideDoneButton(){
	document.getElementById('done').style.display = 'none';
}

function showDoneButton(){
	document.getElementById('done').style.display = 'block';
}

function hideLoginButton(){
	disableInputFields();
	document.getElementById('loginLabel').style.display = 'none';
}

function showLoginButton(){
	enableInputFields();
	document.getElementById('logoutLabel').style.display = 'none';
	document.getElementById('loginLabel').style.display = 'block';
}

function loginOn(elementID){
	document.getElementById(elementID).style.background = "url(Loginon.png) no-repeat top left";
}

function loginOff(elementID){
	document.getElementById(elementID).style.background = "url(Loginoff.png) no-repeat top left";
}

function hideLogoutButton(){
	document.getElementById('logoutLabel').style.display = 'none';
}

function showLogoutButton(){
	disableInputFields();
	document.getElementById('loginLabel').style.display = 'none';
	document.getElementById('logoutLabel').style.display = 'block';
}

function logoutOn(elementID){
	document.getElementById(elementID).style.background = "url(Logouton.png) no-repeat top left";
}

function logoutOff(elementID){
	document.getElementById(elementID).style.background = "url(Logoutoff.png) no-repeat top left";
}

function enterflip(){
	document.getElementById('fliprollie').style.display = 'block';
}

function exitflip(){
	document.getElementById('fliprollie').style.display = 'none';
}

function messageOverlayButtonDown(){
	document.getElementById('messageOverlayButton').style.background="url(ok_black.png) no-repeat top left";
}
