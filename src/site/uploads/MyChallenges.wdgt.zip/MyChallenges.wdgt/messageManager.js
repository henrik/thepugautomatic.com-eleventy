/*
author>
            Matthias Hader (R/GA)
            Nick Coronges (R/GA)
            Jeff Baxter (R/GA) - Design
</author>
<company>NIKE</company>
<copyright>(c)2006 NIKE ALL RIGHTS RESERVED</copyright>
 */
function popUpMessageBox(dispensable,messageText){
	if(dispensable == true){
		document.getElementById('messageOverlayButton').style.display="block";
	}else{
		document.getElementById('messageOverlayButton').style.display="none";
	}
	document.getElementById('messageOverlayText').innerHTML = messageText;
	document.getElementById('messageOverlayText').style.display="block";
	document.getElementById('messageOverlay').style.display="block";
	disableInputFields();
}

function popUpMessageBoxWithLink(dispensable,messageText,httplink){
	if(dispensable == true){
		document.getElementById('messageOverlayButton').style.display="block";
	}else{
		document.getElementById('messageOverlayButton').style.display="none";
	}
	document.getElementById('messageOverlayText').innerHTML = messageText + "<br/><br/><a onclick=\"openHTTPLink('"+httplink+"');\">Upgrade</a>";
	document.getElementById('messageOverlayText').style.display="block";
	document.getElementById('messageOverlay').style.display="block";
	disableInputFields();
}

function openHTTPLink(url){
	if(window.widget){
		widget.openURL(url);
	}
}

function dispenseMessageOverlay(){
	document.getElementById('messageOverlay').style.display="none";
	document.getElementById('messageOverlayText').innerHTML = "";
	document.getElementById('messageOverlayButton').style.background="url(ok_red.png) no-repeat top left";
	if(g_loggedIN == false) enableInputFields();
}

function debug(msg){
	if (debugMode == true) document.getElementById('debug').innerHTML +=msg+"<br/>";
}

function flushDebug(){
	if (debugMode == true) document.getElementById('debug').innerHTML = "";
}