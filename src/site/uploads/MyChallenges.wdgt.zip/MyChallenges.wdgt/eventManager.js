/*
author>
            Matthias Hader (R/GA)
            Nick Coronges (R/GA)
            Jeff Baxter (R/GA) - Design
</author>
<company>NIKE</company>
<copyright>(c)2006 NIKE ALL RIGHTS RESERVED</copyright>
 */
function handleActionSubmit(){
	document.getElementById("usernameField").blur();
	document.getElementById("passwordField").blur();
	var username = document.getElementById("usernameField").value;
	var pass = document.getElementById("passwordField").value;
	if(username == ""){
			document.getElementById("usernameField").focus();
	}
	else if (pass == "") {
		document.getElementById("passwordField").focus();
	}
	prepareLogin();
	return false;
}