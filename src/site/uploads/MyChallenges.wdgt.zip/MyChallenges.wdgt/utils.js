/*
author>
            Matthias Hader (R/GA)
            Nick Coronges (R/GA)
            Jeff Baxter (R/GA) - Design
</author>
<company>NIKE</company>
<copyright>(c)2006 NIKE ALL RIGHTS RESERVED</copyright>
 */
function getBSESSIONIDKeyValue(subjectstring){
	var regexBSESSIONID = /BSESSIONID=[A-Z0-9]+/;
	if(testMode == true) regexBSESSIONID = /JSESSIONID=[A-Z0-9]+/;
	var resultBSESSIONID = subjectstring.match(regexBSESSIONID);
	if(resultBSESSIONID){
		var result = new String(resultBSESSIONID[0]);
		return result;
	}
	else {
		return "";
	}
}

function getBSESSIONIDValue(subjectstring){
	var result = getBSESSIONIDKeyValue(subjectstring);
	if(result != "") return result.substr(11);
	else return result;
}

function getParsedDateYYMMDD(date){
	var YYYYMMDD = date.substr(0,10);
	var HHMMSS = date.substr(11,8);
	var ZONE = date.substr(19);
	var YYYYMMDDArray = YYYYMMDD.split("-");
	if(YYYYMMDDArray.length == 3){
		var MM = YYYYMMDDArray[1];
		var DD = YYYYMMDDArray[2];
		var YY = YYYYMMDDArray[0].substr(2);
		DD = DD-getDayOffset(HHMMSS,ZONE);
		if(DD<10){
			DD = "0"+DD;
		}
		return MM+"/"+DD+"/"+YY;
	}
}

function getDateInstance(date){
	var YYYYMMDD = date.substr(0,10);
	var HHMMSS = date.substr(11,8);
	var ZONE = date.substr(19);
	var YYYYMMDDArray = YYYYMMDD.split("-");
	if(YYYYMMDDArray.length == 3){
		var MM = YYYYMMDDArray[1];
		var DD = YYYYMMDDArray[2];
		var YYYY = YYYYMMDDArray[0];
		DD = DD-getDayOffset(HHMMSS,ZONE);
		//alert(YYYY+","+MM+","+DD);
		var jsMonth = (parseInt(MM,10)-1);
		//alert(MM + "->" +jsMonth);
		var dateInstance = new Date(YYYY,jsMonth,DD);
		return dateInstance;
	}
}

function getWeekDifference(startTime,endTime){
	startTimeObj = getDateInstance(startTime);
	endTimeObj = getDateInstance(endTime);
	diffMillis = endTimeObj - startTimeObj;
	diffWeeks = Math.round(diffMillis/(1000*60*60*24*7));
	return diffWeeks;
}

function getMilliDifference(startTime,endTime){
	startTimeObj = getDateInstance(startTime);
	endTimeObj = getDateInstance(endTime);
	diffMillis = endTimeObj - startTimeObj;
	return diffMillis;
}

function getMillisPassed(startTime){
	startTimeObj = getDateInstance(startTime);
	var currentDate = new Date();
	var diffMillis = currentDate - startTimeObj;
	//alert (diffMillis + "=" + currentDate + "-" + startTimeObj);
	if(diffMillis < 0) return 0;
	else return diffMillis;
}

function getDaysLeftFromNow(endTime){
	currentDate = new Date();
	//alert(currentDate.getTime());
	//alert(endTime);
	endTimeObj = getDateInstance(endTime);
	diffMillis = endTimeObj.getTime() - currentDate.getTime();
	if(diffMillis <= 0){
		return "0";
	}
	else{
		diffDays = Math.round(diffMillis/(1000*60*60*24));
		return diffDays+"";
	}
}


function getDayOffset(hhmmss,zone){
	var currentDate = new Date();
	var timezoneoffset = currentDate.getTimezoneOffset();
	//get minutes of hhmmss
	hhmmssMinutes = getHHMMSSMinutes(hhmmss);
	var zonePrefix = zone.substr(0,1);
	var zoneMinutes = getHHMMMinutes(zone.substr(1));
	if(zonePrefix == "+"){
		var offestresult = hhmmssMinutes - (timezoneoffset+zoneMinutes);
		if(offestresult < 0) return 1;
		else return 0;
	}
	else{
		var offestresult = hhmmssMinutes - (timezoneoffset-zoneMinutes);
		if(offestresult < 0) return 1;
		else return 0;
	}
}

function getHHMMSSMinutes(hhmmss){
	var hhmmssArray = hhmmss.split(":");
	var hourMinutes = hhmmssArray[0]*60;
	var minuteMinutes = hhmmssArray[1]*1;
	var secMinutes = hhmmssArray[2]/60;
	return hourMinutes+minuteMinutes+secMinutes;
}

function getHHMMMinutes(hhmm){
	var hhmmArray = hhmm.split(":");
	var hourMinutes = hhmmArray[0]*60;
	var minuteMinutes = hhmmArray[1]*1;
	return hourMinutes+minuteMinutes;
}

function getTimeInPrimeFormatFromMilliSeconds(time){
	timeLong = parseFloat(time);
	var minutes = Math.floor(timeLong/60000);
	var minutesRest = timeLong%60000;
	var seconds = Math.floor(minutesRest/1000);
	if(parseInt(seconds,10) < 10) seconds = "0"+seconds;
	return minutes+"'"+seconds+"''";
}

function setPrecision(floatNumber,precision){
	floatNumber = floatNumber * 1.0;
	var formattedFloatNumber = floatNumber.toFixed(precision);
	var roundedFloatNumber = Math.round(formattedFloatNumber);
	var diff = formattedFloatNumber - roundedFloatNumber;
	if(diff!=0){
		return formattedFloatNumber;
	}
	else{
		return roundedFloatNumber;
	}
}

function cropFloat(floatNumber,precision){
	var numberSplit = floatNumber.split("\.");
	if(numberSplit.length == 2 && (numberSplit[1].length > precision)){
		if(parseInt(numberSplit[1],10) == 0) return numberSplit[0];
		else return numberSplit[0] + "." + numberSplit[1].substr(0,precision);
	}
	else return floatNumber;
}

// Modified to actually return KM
function getMilesFromKM(kilometers,precision){
    return cropFloat(kilometers+"",precision);
}

function bubblesort2DimArray(arrayList,key){
	var sortedArrayList = arrayList;
	listlength = sortedArrayList.length;
	var securitySwitch = Math.pow(listlength,2);
	var securityCount = 0;
	while(securityCount < securitySwitch){
		var swapped = false;
		for(var i=0;i<listlength-1;i++){
			if(parseFloat(arrayList[i][key]) < parseFloat(arrayList[i+1][key])){
				//alert(arrayList[i][key]+"<"+arrayList[i+1][key] + " -> swap");
				sortedArrayList = swapArrayElements(sortedArrayList,i,i+1);
				swapped = true;
			}
		}
		if(swapped == false){
			return sortedArrayList;
		}
	}
	alert("hit maximum limit: "+ securitySwitch);
	return sortedArrayList;
}

function swapArrayElements(arrayList,lo,hi){
	//alert("swap "+arrayList[lo][1]+" with "+arrayList[hi][1]);
	var swapElement = arrayList[lo];
	arrayList[lo] = arrayList[hi];
	arrayList[hi] = swapElement;
	return arrayList;
}