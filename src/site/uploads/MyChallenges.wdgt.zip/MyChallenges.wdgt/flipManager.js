/*
author>
            Matthias Hader (R/GA)
            Nick Coronges (R/GA)
            Jeff Baxter (R/GA) - Design
</author>
<company>NIKE</company>
<copyright>(c)2006 NIKE ALL RIGHTS RESERVED</copyright>
 */
function flipSide(from,to,transitionType){
	var fromElement = document.getElementById(from);
	var toElement = document.getElementById(to);
	if (fromElement.style.display != "none"){
		if (window.widget) widget.prepareForTransition(transitionType);
		//organize the "flip to" Sides
		organizeFlipDestinationSide(transitionType);
		fromElement.style.display="none";
		toElement.style.display="block";
		if (window.widget) setTimeout('widget.performTransition();',0);
	}
}

function organizeFlipDestinationSide(transitionType){
	if(transitionType == "ToBack"){
		document.getElementById('done').style.background = "url(Done_red.png) no-repeat top left";
		var username = document.getElementById("usernameField").value;
		var pass = document.getElementById("passwordField").value;
		if(username == ""){
			document.getElementById("usernameField").focus();
		}
		else if (pass == "") {
			document.getElementById("passwordField").focus();
		}
	}
	else if(transitionType == "ToFront"){
		document.getElementById('fliprollie').style.display="none";
	} 
}