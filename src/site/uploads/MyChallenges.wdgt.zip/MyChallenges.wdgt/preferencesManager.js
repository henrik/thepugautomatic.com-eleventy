/*
author>
            Matthias Hader (R/GA)
            Nick Coronges (R/GA)
            Jeff Baxter (R/GA) - Design
</author>
<company>NIKE</company>
<copyright>(c)2006 NIKE ALL RIGHTS RESERVED</copyright>
 */
var usernamePref = "nikeplusUsername";
var passwordPref = "nikeplusPassword";
var pinPref = "nikeplusPin";
var lastChallengeIDPref = "nikeplusLastChallengeID";

function onShowDashboard(){
	debug("show dashboard");
	validateWidget();
}

function onClickSwoosh(){
	debug('swoosh clicked');
	if(window.widget){
		pin = getPinPreference();
		debug('pin for login '+pin);
		if(pin != ""){
			openNikePlusWithToken(pin);
		}
		else{
			widget.openURL("http://www.nikeplus.com");
		}
	}
}

function getUsernamePreference(){
	var username = widget.preferenceForKey(usernamePref);
	if (!username || (username == "undefined")) {username = "";}
	return username;
}

function getPinPreference(){
	var pin = widget.preferenceForKey(pinPref);
	if (!pin || (pin == "undefined")) {pin = "";}
	return pin;
}

function getLastChallengeIDPreference(){
	lastChallengeID = widget.preferenceForKey(lastChallengeIDPref);
	if (!lastChallengeID || (lastChallengeID == "undefined")) {lastChallengeID = "";}
	return lastChallengeID;
}

function setUsernamePreference(username){
	widget.setPreferenceForKey(username,usernamePref);
}

function setPinPreference(pin){
	widget.setPreferenceForKey(pin,pinPref);
}

function setLastChallengeIDPreference(challengeID){
	widget.setPreferenceForKey(challengeID,lastChallengeIDPref);
}

function hideChallengeSelector(){
	document.getElementById('challengeSelectContainer').style.display = 'none';
}

function showChallengeSelector(){
	document.getElementById('challengeSelectContainer').style.display = 'block';
}

function prepareLogout(){
	flushDebug();
	processLogout();
	//delete all the preferences
	if(window.widget){
		setUsernamePreference(null);
		setPinPreference(null);
		setLastChallengeIDPreference(null);
	}
	//hide the done button
	hideDoneButton();
	//hide dropdown
	hideChallengeSelector();
	//show Login Button
	showLoginButton();
	//and now start from the first point and setup
	setup();
}

function prepareLogin(){
	var username = document.getElementById("usernameField").value;
	var password = document.getElementById("passwordField").value;
	document.getElementById("passwordField").value = "";
	if(window.widget){
		setUsernamePreference(username);
		setPinPreference(null);
		setLastChallengeIDPreference(null);
	}
	hideLoginButton();
	processLogin(username,password);
}

function disableInputFields(){
	document.getElementById("usernameField").setAttribute("readonly","readonly");
	document.getElementById("passwordField").setAttribute("readonly","readonly");
}

function enableInputFields(){
	document.getElementById("usernameField").removeAttribute("readonly");
	document.getElementById("passwordField").removeAttribute("readonly");
}

function getChallengeSelectBox(ChallegeDOM){
	html = 	"<div class=\"label\" id=\"selectChallengeLabel\">Select a Challenge</div>"+
			"<select size=\"1\" id=\"selectChallengeField\" onchange=\"challengeSelectionChanged();\">"+
			"<option value=\"0\">Select a Challenge...</option>";
	activeChallenges = "";
	completedChallenges = "";
	activeCount = 0;
	completedCount = 0;
	lastSelectedChallengeID = "";
	if(window.widget) lastSelectedChallengeID = getLastChallengeIDPreference();
	var challengesNodeIterator = ChallegeDOM.getElementsByTagName("challenge");
	debug("challenges node iterator: "+challengesNodeIterator.length);
	if(challengesNodeIterator.length == 0){
		return "";
	}
	for(var i=0;i<challengesNodeIterator.length;i++){
		var challengeID = ChallegeDOM.getElementsByTagName("challenge")[i].getAttribute("id");
		var challengeName = ChallegeDOM.getElementsByTagName("challenge")[i].childNodes[1].firstChild.data;
		var challengeActive = ChallegeDOM.getElementsByTagName("challenge")[i].childNodes[3].firstChild.data;
		if(challengeActive=="true"){
			activeCount++;
			if(challengeID == lastSelectedChallengeID){
				showDoneButton();
				activeChallenges += "<option value=\""+challengeID+"\" selected>"+challengeName+"</option>";
			}
			else{
				activeChallenges += "<option value=\""+challengeID+"\">"+challengeName+"</option>";
			}
		}
		else{
			completedCount++;
			if(challengeID == lastSelectedChallengeID){
				showDoneButton();
				completedChallenges += "<option value=\""+challengeID+"\" selected>"+challengeName+"</option>";
			}
			else{
				completedChallenges += "<option value=\""+challengeID+"\">"+challengeName+"</option>";
			}
		}
	}
	html += "<optgroup label=\"Active ("+activeCount+")\">"+
				activeChallenges+
			"</optgroup>"+
			"<optgroup label=\"Completed ("+completedCount+")\">"+
				completedChallenges+
			"</optgroup>"+
		"</select>";
		
	return html;
}

function challengeSelectionChanged(){
	selectedChallengeID = document.getElementById("selectChallengeField").options[document.getElementById("selectChallengeField").selectedIndex].value;
	if(selectedChallengeID!=0){
		if(window.widget){
			setLastChallengeIDPreference(selectedChallengeID);	
		}
		processGetChallengeDetail(selectedChallengeID);
		showDoneButton();
	}
	else{
		popUpMessageBox(true,"there was an error in challenge selection");
	}
}


