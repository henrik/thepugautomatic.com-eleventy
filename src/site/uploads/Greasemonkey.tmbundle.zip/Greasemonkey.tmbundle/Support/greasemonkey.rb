# Greasemonkey bundle commands for TextMate
# By Henrik Nyh <http://henrik.nyh.se> 2007-03-04.
# Free to modify and redistribute non-commercially with due credit.

# Useful stuff for tm_dialog
require "#{ENV['TM_SUPPORT_PATH']}/lib/osx/plist"
require "#{ENV['TM_SUPPORT_PATH']}/lib/escape"
require "#{ENV['TM_SUPPORT_PATH']}/lib/dialog"
require "#{ENV['TM_SUPPORT_PATH']}/lib/progress"

# Contains pretty much everything that isn't the command methods
require "#{ENV['TM_BUNDLE_SUPPORT']}/support.rb"
# Code related to Userscripts.org
require "#{ENV['TM_BUNDLE_SUPPORT']}/userscriptsorg.rb"


class Greasemonkey
	# Continues adding @includes or @excludes when hitting the Enter key.
	def continue_header_url
		line_number = ENV["TM_LINE_NUMBER"].to_i-1
		line = @script.file_lines[line_number]

		exit unless line =~ %r{^(\s*//\s*@(in|ex)clude\s*).*([\r\n]+)}
		print $3 + $1
	end
	
	# For a saved userscript, uploads it to Userscripts.org
	def upload_to_userscripts
		@script.ensure_saved
		@script.ensure_valid
		begin
			UserscriptsOrg::upload(@script)
		rescue Exception => e 
			puts $!
		end
	end


	# For an installed userscript, updates the stored @name, @namespace, @description, @include and @exclude metadata according to the values in the script file. These values are not automatically kept in sync by Greasemonkey. Particularly useful when you've changed @include or @exclude values. Note that changing the @name and @namespace can cause ill effects when re-installing a script, as they are the unique identifier.
	def update_metadata
		@script.ensure_valid
		begin
			@config.xml do |xml|			
				script = xml.root.elements["Script[@filename='#{@script.file_name}']"] or raise NotInstalledScriptException	
				script.add_attribute("name", @script.name)
				script.add_attribute("namespace", @script.namespace)
				script.add_attribute("description", @script.description)
				script.elements.delete_all("*")
				@script.includes.each {|inc| script.add_element("Include").text = inc }
				@script.excludes.each {|exc| script.add_element("Exclude").text = exc }
			end
			puts "Metadata has been updated."
		rescue NotInstalledScriptException
			abort "Metadata was NOT updated as this file is not an installed script."
		end
	end


	# Open any script from a list of installed userscripts.	
	def open_installed_script
		xml = @config.xml
		
		scripts = []

		xml.root.elements.to_a('Script').each do |script|
			scripts << {"name" => script.attributes["name"], "filename" => script.attributes["filename"]}
		end
		
		abort "You do not have any installed scripts to open!" if scripts.empty?

		scripts.reverse!  # Reverse order of installation

		parameters = {
			"installOrderScripts" => scripts,
			"alphabeticalScripts" => scripts.sort {|one, two| one["name"].downcase <=> two["name"].downcase}
		}
		
		# Flags: modal, centered, parameters
		dialog = `$DIALOG -mcp #{e_sh parameters.to_plist} #{e_sh "#{ENV['TM_BUNDLE_SUPPORT']}/nib/OpenInstalledScript.nib"}`
		pl = PropertyList::load(dialog)
		
		exit unless pl["returnButton"] == "Load"  # Bail if the user cancelled
		
		by_install_date = pl["byInstallDate"]==1 ? true : false
		source = if by_install_date then pl["installOrderScripts"] else pl["alphabeticalScripts"] end
		index = if by_install_date then pl["selectedDate"] else pl["selectedAlpha"] end || 0
		script = source[index]
		
		filename = "#{@config.directory}/#{script["filename"]}"
		MyTextMate.open(filename)
	end
	

	# Inverts the cosmos
	def reload_firefox(time=nil)
		`osascript <<'END'
			tell app "Firefox" to activate
			tell app "System Events"
				if UI elements enabled then
					keystroke "r" using command down
					-- Fails if System Preferences > Universal access > "Enable access for assistive devices" is not on 
				else
					tell app "Firefox" to Get URL "javascript:location.reload();" inside window 1
					-- Fails if Firefox is set to open URLs from external apps in new tabs.
				end if
			end tell
			#{%{
				delay #{time.to_i}
				tell app "TextMate" to activate
			} if time}
END`
	end


	# For an installed userscript, uninstalls it and closes the document.	
	def uninstall_script
		@script.ensure_installed

		begin
			xml = @config.xml
			xml.root.elements.delete("Script[@filename='#{@script.file_name}']") or raise NotInstalledScriptException

			button = TextMate::Dialog.alert(:warning, %Q{Uninstall "#{@script.name}"?}, "The file will be moved to the Trash folder.", "Uninstall", "Cancel")
			exit if button == "Cancel"
			
			@config.xml = xml  # Save XML if we're still around
		rescue NotInstalledScriptException
			abort "This file is not an installed script!"
		end

		# Move the script file to trash
		`mv #{e_sh @script.file_path} #{e_sh "#{ENV["HOME"]}/.Trash"}`

		# Close the document
		`osascript <<'END'
			tell application "TextMate" to set isUnsaved to modified of document 1
			tell application "System Events"
				#{AppleScript.ensure_gui_scripting("Script was uninstalled, but the window could not be closed.")}
				keystroke "w" using command down -- close tab
				if isUnsaved then keystroke "d" using command down -- don't save
			end tell
END`	
	end


	# For an installed userscript, opens up "about:config" in Firefox and filters it to the GM_get/setValue() values for that script.	
	def manage_gm_values
		@script.ensure_installed
		key = "greasemonkey.scriptvals.#{@script.namespace}/#{@script.name}"
		key.sub!(/.*~/, '')  # Work around weird bug where "~" is output as "a"...

		`osascript <<'END'
			tell application "System Events" to set firefoxIsRunning to (name of processes) contains "firefox-bin"

			tell application "Firefox"
				activate
				if not firefoxIsRunning then delay 2
				Get URL "about:config" inside window 1
			end tell

			tell application "System Events"
				#{AppleScript.ensure_gui_scripting("Could not filter.")}
				delay 2
				(keystroke "#{key}")
			end tell
END`
	end


	# Installs the current (assumedly unsaved) document as a Greasemonkey userscript, and starts editing the installed file instead.	
	def install_and_edit
		@script.avoid_installed
		@script.ensure_valid
		
		# Make an initial choice of filename
		filename = @script.name.gsub(/\W/, '')[0,24].downcase + ".user.js"
		
		# Is a script already installed with this name+namespace?
		xml = @config.xml
		
		same_script = xml.root.elements["Script[@name='#{@script.name}'][@namespace='#{@script.namespace}']"]
		
		if same_script  # Overwrite, reusing that filename
			filename = same_script.attributes["filename"]
		else  # Make sure we don't overwrite anything
			while @config.file_lines.any? {|line| line =~ /filename='#{filename}'/ }  # filename is being used
				filename.sub!(/(.)\.user\.js$/) { "#{$1.to_i+1}.user.js" }  # increment it
			end
		end
		
		# Create script
		new_script_file_name = "#{@config.directory}/#{filename}"
		File.open(new_script_file_name, "w") {|file| file.puts @script.file_data}
		
		# Update config
		xml.root.delete same_script if same_script

		new_script = xml.root.add_element "Script",
			{"name" => @script.name,
			 "namespace" => @script.namespace,
			 "filename" => filename,
			 "description" => @script.description,
			 "enabled" => "true"}

		@script.includes.each {|inc| new_script.add_element("Include").text = inc }
		@script.excludes.each {|exc| new_script.add_element("Exclude").text = exc }
		@config.xml = xml
		
		# Close old file and open the new one
		# This is done in a detached process to survive the closing of the file
		`{
		osascript <<'END'
			tell app "TextMate"
				activate
				set isUnsaved to modified of document 1
				tell application "System Events"
					#{AppleScript.ensure_gui_scripting("Script was installed and will be opened, but the old document could not be closed.")}
					keystroke "w" using command down -- close tab
					if isUnsaved then keystroke "d" using command down -- don't save
				end tell
			end tell
END
		#{MyTextMate.open(new_script_file_name, :output_command)}
		} &>/dev/null &`
		
	end

	
# In selection or entire document, comment out all GM_logs if any were uncommented; otherwise uncomment all GM_logs.
def toggle_log_comments
	any_uncommented_logs = @script.file_lines.any? {|line| line.reverse =~ %r{\).*\(gol_MG(?!\s*//)}i }  # Fake lookbehind
#		any_commented_logs = @script.file_lines.any? {|line| line =~ %r{//\s*GM_log\([^)]*\)} }
	@script.file_lines.each do |line|
		line.sub!(%r{(//)?(\s*GM_log\(.*\))}i, '//\2') if any_uncommented_logs  # Comment all
		line.sub!(%r{//(\s*GM_log\(.*\))}i, '\1') unless any_uncommented_logs  # Uncomment all
		print line
	end
end


# In selection or entire document, remove all GM_logs.
def remove_logs
	@script.file_lines.each do |line|
		if line.sub!(%r{\s*(//)?\s*GM_log\(.*\);[\t ]*}i, '')
			print line unless line.strip.empty?
		else
			print line
		end
	end
end

end