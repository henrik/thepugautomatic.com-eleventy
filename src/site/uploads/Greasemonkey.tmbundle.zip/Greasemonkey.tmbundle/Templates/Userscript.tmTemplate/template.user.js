// ==UserScript==
This header block will be replaced by the contents of snippet.user.js.
// ==/UserScript==



/* Your favorite functions go here. */