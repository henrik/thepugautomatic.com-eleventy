/* HNColoredBox */

#import <Cocoa/Cocoa.h>

@interface HNColoredBox : NSBox
{
	NSColor* borderColor;
}
- (NSColor *)borderColor;
- (void)setBorderColor:(NSColor *)theBorderColor;
- (void)resetBorderColor;
@end
