//
//  main.m
//  Photo Rebooth
//
//  Created by Henrik Nyh on 2006-12-29.
//  Free to modify and redistribute with due credit.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
