/* MyController */

#import <Cocoa/Cocoa.h>
#import <Quartz/Quartz.h>
#import "HNQCView.h"

@interface Controller : NSObject {
	IBOutlet HNQCView *composition;
}
- (IBAction)displayDialog:(id)sender;
@end
