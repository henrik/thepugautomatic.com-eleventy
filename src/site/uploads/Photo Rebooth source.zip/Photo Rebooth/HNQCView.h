/* MyQCView */

#import <Cocoa/Cocoa.h>
#import <Quartz/Quartz.h>
#import "HNColoredBox.h"

@interface HNQCView : QCView {
	HNColoredBox *container;
}
- (void)useComposition:(NSString *)filename;
- (BOOL)openFile:(NSString *)filename;
@end
