#import "HNColoredBox.h"

@implementation HNColoredBox

// Inspired by http://www.red-sweater.com/blog/221/flex-your-hig

- (id)initWithFrame:(NSRect)frameRect {
	if (self = [super initWithFrame:frameRect])
		borderColor = [[NSColor grayColor] retain];	
	return self;
}

- (void)dealloc {
	[borderColor release];
	[super dealloc];
}

- (NSColor *)borderColor {
    return borderColor; 
}

- (void)setBorderColor:(NSColor *)theBorderColor {
    if (borderColor != theBorderColor) {
        [borderColor release];
        borderColor = [theBorderColor retain];
    }
	[self display];
}

- (void)resetBorderColor {
	[self setBorderColor: [NSColor grayColor]];
}

- (void)drawRect:(NSRect)rect {
	NSRect myBounds = [self bounds];
	[borderColor set];
	NSRectFillUsingOperation(myBounds, NSCompositeSourceOver);
}

@end
