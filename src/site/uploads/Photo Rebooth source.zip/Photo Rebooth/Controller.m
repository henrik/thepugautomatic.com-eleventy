#import "Controller.h"

@implementation Controller

- (IBAction)displayDialog:(id)sender {
    NSArray *fileTypes = [NSArray arrayWithObject:@"jpg"];
    NSOpenPanel *oPanel = [NSOpenPanel openPanel];

	NSString *desktopDirectory;
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDesktopDirectory, NSUserDomainMask, YES);
	if ([paths count] > 0)
		desktopDirectory = [paths objectAtIndex:0];
	
    int result = [oPanel runModalForDirectory:desktopDirectory file:nil types:fileTypes];
					
	if (result == NSOKButton) {
		NSString *aFile = [[oPanel filenames] objectAtIndex:0];
		[composition openFile:aFile];
    }
}

- (void) awakeFromNib {
	[composition useComposition:@"untwirl"];
}

// NSApplication delegate method
- (BOOL)application:(NSApplication *)sender openFile:(NSString *)filename {
	return [composition openFile:filename];
}

@end
