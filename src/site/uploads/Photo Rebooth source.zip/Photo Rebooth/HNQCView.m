#import "HNQCView.h"

@interface HNQCView (Private)
- (NSString *)fileIfAcceptableDrag:(id <NSDraggingInfo>)sender;
@end

@implementation HNQCView

- (id)initWithFrame:(NSRect)frameRect {
    self = [super initWithFrame:frameRect];
	[self registerForDraggedTypes:[NSArray arrayWithObjects:NSTIFFPboardType, NSFilenamesPboardType, nil]];
    return self;
}
- (void)dealloc {
    [self unregisterDraggedTypes];
    [super dealloc];
}
- (void)awakeFromNib {
	container = (HNColoredBox *)[[self superview] superview];  // Not elegant, but had no luck with an outlet
}

- (void)useComposition:(NSString *)filename {
	NSString *untwirlFilename = [[NSBundle mainBundle] pathForResource:filename ofType:@"qtz"];
	[self loadCompositionFromFile: untwirlFilename];
	[self startRendering];
}

- (BOOL)openFile:(NSString *)filename {
	NSImage *image = [[NSImage alloc] initWithContentsOfFile:filename];
	[self setValue:image forInputKey:@"Input"];
	[image release];
	[[NSDocumentController sharedDocumentController] noteNewRecentDocumentURL: [NSURL fileURLWithPath:filename]];
	return YES;
}

// Drag-and-drop stuff

- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender {
	if ([self fileIfAcceptableDrag:sender]) {
		[container setBorderColor:[NSColor highlightColor]];  // Highlight
		return NSDragOperationGeneric;
	} else {
		return NSDragOperationNone;
	}
}
- (void)draggingExited:(id <NSDraggingInfo>)sender {
	[container resetBorderColor];
}
- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender {
	[container resetBorderColor];
	NSString *filename = [self fileIfAcceptableDrag:sender];
    if (!filename)
		return NO;
	else 
		return [self openFile:filename];
}

@end

@implementation HNQCView (Private)

- (NSString *)fileIfAcceptableDrag:(id <NSDraggingInfo>)sender {  // Return filename string if we accept drops; otherwise NULL
    NSPasteboard *pboard = [sender draggingPasteboard];

    if (![[pboard types] containsObject:NSFilenamesPboardType]) return NULL;  // Only NSFilenames
	NSArray *files = [pboard propertyListForType:NSFilenamesPboardType];
	if ([files count] != 1) return NULL;  // Only single files
	
	NSString *filename = [files lastObject];
	if (![[filename pathExtension] isCaseInsensitiveLike:@"jpg"]) return NULL;
	return filename;
}

@end
