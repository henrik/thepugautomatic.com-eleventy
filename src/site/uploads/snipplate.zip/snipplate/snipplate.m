// snipplate
// By Henrik Nyh <http://henrik.nyh.se> 2007-03-01.
// Sends the keystrokes "option + cursor right, tab" to the active application, which is intended to go to the end of some initial TextMate snippet and trigger it, for use in templates <http://henrik.nyh.se/2007/02/27/snippet-power-templates-in-textmate/>. 

#import <Cocoa/Cocoa.h>

void press(int key_code) {
	CGPostKeyboardEvent(0, key_code, true);
}

void release(int key_code) {
	CGPostKeyboardEvent(0, key_code, false);
}

void press_release(int key_code) {
	press(key_code);
	release(key_code);
}

int main (int argc, const char* argv[]) {

	// Refer to http://www.google.com/codesearch?hl=en&q=show:IGxwXV6tyUA:Uu4Kz_upvi8:zO9QVB2Bs-w&sa=N&ct=rd&cs_p=https://www.copilot.com/copilot_helper_src.zip&cs_f=temp/src/helpers_000093/gpl/vnc_macsrc/Host/OSXvnc/OSXvnc-server/kbdptr.h for key codes
	int KEY_OPTION = 58;
	int KEY_CURSOR_RIGHT = 124;
	int KEY_TAB = 48;

	press(KEY_OPTION);
	press_release(KEY_CURSOR_RIGHT);
	release(KEY_OPTION);
	press_release(KEY_TAB);

    return 0;
}